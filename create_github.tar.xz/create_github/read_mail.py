import imaplib
import email
import re
import time
from email.header import decode_header

HOST = "imap.gmail.com"
PORT = 993
# USERNAME = "kalawssimatrix@gmail.com"
# PASSWORD = "bwokhaeitjbdhiqm"

# PORT = 993
USERNAME = "kalawssimatrix@gmail.com"
PASSWORD = "onxzzjwponsfoogk"

# from_email="uwdhwarq2763@techxbox.eu.org"

def _email_to_matches(mail, msg_id, address):
    _, data = mail.fetch(msg_id, "(BODY.PEEK[HEADER.FIELDS (TO)])")
    return address.lower() in data[0][1].decode().lower()

def get_code(from_email, retries=10, delay=6):
    print("=" * 49)
    print(" Login to Email ;)")
    print("=" * 49)
    print(f"[IMAP] Connecting to {HOST}:{PORT} ...")
    mail = imaplib.IMAP4_SSL(HOST, PORT)
    print(f"[IMAP] Connected. Logging in as {USERNAME} ...")
    typ, data = mail.login(USERNAME, PASSWORD)
    print(f"[IMAP] Login response: {typ} {data}")
    typ, data = mail.select("INBOX")
    print(f"[IMAP] INBOX selected: {typ} — {data[0].decode()} messages")

    for attempt in range(1, retries + 1):
        print(f"Attempt {attempt}/{retries} — searching for email to {from_email}...")
        _, msg_ids = mail.search(None, 'FROM "noreply@github.com"')
        ids = msg_ids[0].split()
        ids = [i for i in ids if _email_to_matches(mail, i, from_email)]
        print(f"  Matched {len(ids)} email(s)")
        if ids:
            _, data = mail.fetch(ids[-1], "(RFC822)")
            msg = email.message_from_bytes(data[0][1])
            body = ""
            if msg.is_multipart():
                for part in msg.walk():
                    if part.get_content_type() == "text/plain":
                        body = part.get_payload(decode=True).decode()
                        break
            else:
                body = msg.get_payload(decode=True).decode()

            match = re.search(r'(?:entering the code below|launch code)[:\s]*(\d{6,8})', body, re.IGNORECASE)
            if match:
                mail.logout()
                return match.group(1)
            else:
                print("  Email found but no code matched — body preview:")
                print(f"  {body[:200]}")

        time.sleep(delay)

    mail.logout()
    return None

# get_code(from_email, retries=10, delay=6)

if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("Usage: python read_mail.py <from_email>")
        sys.exit(1)
    result = get_code(sys.argv[1], retries=1, delay=0)
    print(f"Code: {result}")
