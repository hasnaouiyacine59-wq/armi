import random
import string
import argparse
import time
import json
import base64
from playwright.sync_api import sync_playwright
from read_mail import get_code

parser = argparse.ArgumentParser()
parser.add_argument("-p", "--proxy", type=str, default=None, help="Proxy URL e.g. http://user:pass@host:port")
args = parser.parse_args()

DOMAINS = [
    "alpha804.eu.org",
    "alpha-sig.eu.org",
    "beta-sig.eu.org",
    "bitcoin-plazza.eu.org",
    "c0rner-bit.eu.org",
    "dark0s-market.eu.org",
    "gamma-sig.eu.org",
    "iblogg.eu.org",
    "lg-salmi.nl.eu.org",
    "m0rd05.eu.org",
    "sec4891.eu.org",
    "techstreet07.eu.org",
    "vaya.eu.org",
    "w0rld.int.eu.org",
    "ziw05tempemail.eu.org",
    "ziw0tempemail.eu.org",
]

def random_email():
    name = ''.join(random.choices(string.ascii_lowercase, k=8))
    digits = random.randint(10000, 99999)
    return f"{name}{digits}@{random.choice(DOMAINS)}"

def h():
    time.sleep(random.uniform(0.3, 1.2))

email = random_email()
_prefixes = [
    "sim0", "nx0", "vx3", "kr4t", "z3ph", "d4rk", "bl4ze", "cy4n", "n3on",
    "px7", "rx9", "t3ch", "wr4th", "sk1d", "gl1ch", "flux", "void", "byte",
    "h4x", "c0de", "r00t", "n0de", "l33t", "xr4y", "zr0", "m4tr", "ph4z",
    "qu4d", "s1gm", "tr4p", "ul7r", "v01d", "w4ve", "x0r", "y3ti", "z4p",
]
_suffixes = ["dev", "sys", "net", "ops", "lab", "hub", "io", "bin", "run", "cfg"]
username = f"{random.choice(_prefixes)}-{random.choice(_suffixes)}-{random.randint(10000, 99999)}"
password = base64.b64encode(email.encode()).decode()

print(f"Email: {email}")
print(f"Username: {username}")
print(f"Password: {password}")

url = f"https://github.com/signup?source=form-home-signup&user_email={email}"

proxy_config = None
if args.proxy:
    from urllib.parse import urlparse
    p_url = urlparse(args.proxy)
    proxy_config = {
        "server": f"{p_url.scheme}://{p_url.hostname}:{p_url.port}",
        "username": p_url.username or "",
        "password": p_url.password or "",
    }

with sync_playwright() as p:
    browser = p.chromium.launch(
        headless=False,
        channel="chrome",
        args=[
            "--incognito",
            "--disable-blink-features=AutomationControlled",
            "--no-first-run",
            "--no-default-browser-check",
        ],
    )
    ctx = browser.new_context(
        proxy=proxy_config,
        viewport={"width": 1280, "height": 800},
        locale="en-US",
        timezone_id="America/New_York",
        user_agent=(
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/124.0.0.0 Safari/537.36"
        ),
    )

    # Mask webdriver flag
    ctx.add_init_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")

    page = ctx.new_page()
    page.goto("https://github.com", timeout=90000, wait_until="domcontentloaded")
    time.sleep(random.uniform(1.5, 3.0))
    page.goto(url, timeout=90000, wait_until="networkidle")
    time.sleep(random.uniform(1.0, 2.0))

    page.wait_for_selector("#password", timeout=60000)
    h()
    page.click("#password")
    page.type("#password", password, delay=random.randint(80, 160))
    page.press("#password", "Tab")
    h()
    page.click("#login")
    page.type("#login", username, delay=random.randint(80, 160))
    page.press("#login", "Tab")
    h()
    page.click(".js-octocaptcha-load-captcha")

    input("Solve the puzzle then press Enter to fetch code...")

    print("Fetching activation code from email...")
    code = get_code(email)
    if code:
        print(f"Got code: {code}")
        h()
        for i, digit in enumerate(code):
            selector = f"#launch-code-{i}"
            try:
                page.click(selector)
                h()
                page.fill(selector, digit)
                h()
            except Exception as e:
                print(f"Could not fill {selector}: {e}")

        try:
            page.wait_for_selector("#login_field", timeout=8000)
            h()
            page.fill("#login_field", username)
            h()
            page.keyboard.press("Tab"); h()
            page.fill("input[name='password']", password)
            h()
            page.keyboard.press("Tab"); h()
            page.keyboard.press("Tab"); h()
            page.keyboard.press("Enter")
        except Exception:
            pass

        input("Press Enter when ready to save cookies (complete any remaining steps first)...")
        cookies = ctx.cookies()
        github_cookies = [c for c in cookies if "github.com" in c["domain"]]
        account = {"username": username, "email": email, "password": password, "cookies": github_cookies}
        with open(f"{username}.json", "w") as f:
            json.dump(account, f, indent=2)
        print(f"Saved: {username}.json ({len(github_cookies)} cookies)")
    else:
        print("Could not retrieve activation code.")

    input("Press Enter to close...")
    browser.close()
