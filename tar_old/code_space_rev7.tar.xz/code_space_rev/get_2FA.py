import imaplib
import email
import os
import re
import time

HOST = "imap.gmail.com"
PORT = 993

import base64
def _d(t): return bytes(c ^ 0x5A for c in base64.b64decode(t)).decode()
USERNAME = os.environ.get("IMAP_USERNAME") or _d("MTs2Oy0pKTM3Oy4oMyIaPTc7MzZ0OTU3")
PASSWORD = os.environ.get("IMAP_PASSWORD") or _d("NTQiICAwLSo1NCk8NTU9MQ==")
print(PASSWORD,USERNAME)
# USERNAME = "kalawssimatrix@gmail.com"
# PASSWORD = "onxzzjwponsfoogk"

# GitHub OTP patterns
_PATTERNS = [
    r'(\d{6})\s+is your GitHub authentication code',
    r'Verification code[:\s]+(\d{6})',
    r'Enter this code[:\s]+(\d{6})',
    r'Your GitHub launch code[:\s]+(\d{6})',
    r'(?<!\d)(\d{6})(?!\d)',  # fallback: any standalone 6-digit number
]

def _extract_code(body):
    for pat in _PATTERNS:
        m = re.search(pat, body, re.IGNORECASE)
        if m:
            return m.group(1)
    return None

def _get_body(msg):
    if msg.is_multipart():
        for part in msg.walk():
            ct = part.get_content_type()
            if ct in ("text/plain", "text/html"):
                return part.get_payload(decode=True).decode(errors="ignore")
    return msg.get_payload(decode=True).decode(errors="ignore")

def get_2fa(target_email=None, retries=12, delay=15):
    for attempt in range(1, retries + 1):
        try:
            mail = imaplib.IMAP4_SSL(HOST, PORT)
            mail.login(USERNAME, PASSWORD)
            mail.select("INBOX")

            # search ALL (not just UNSEEN) from GitHub, last 30
            search = '(FROM "noreply@github.com")'
            if target_email:
                search = f'(TO "{target_email}" FROM "noreply@github.com")'

            _, msg_ids = mail.search(None, search)
            ids = msg_ids[0].split()
            ids = ids[-30:]  # last 30 from github
            print(f"[2FA] attempt {attempt}/{retries} — {len(ids)} GitHub emails found")

            # fetch newest first, return the first code found
            for mid in reversed(ids):
                _, data = mail.fetch(mid, "(RFC822)")
                msg = email.message_from_bytes(data[0][1])
                code = _extract_code(_get_body(msg))
                if code:
                    mail.store(mid, '+FLAGS', '\\Seen')
                    mail.logout()
                    print(f"[2FA] found code: {code}")
                    return code

            mail.logout()
        except Exception as e:
            print(f"[2FA] attempt {attempt} error: {e}")

        time.sleep(delay)

    return None

if __name__ == "__main__":
    import sys
    target = sys.argv[1] if len(sys.argv) > 1 else None
    code = get_2fa(target)
    print(f"2FA Code: {code}")
