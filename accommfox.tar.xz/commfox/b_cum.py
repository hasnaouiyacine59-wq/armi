import os, json, time, random, requests, argparse, platform, uuid, socket
from faker import Faker
fake = Faker()

def random_num():
    return random.randint(100, 999)

def generate_user():
    fname = fake.first_name()
    lname = fake.last_name()
    num = random_num()
    DOMAINS = ["techxbox.eu.org", "beta-sig.eu.org", "itchigho.eu.org", "sec4891.eu.org", "iblogg.eu.org", "youoneshell.eu.org"]
    domain = random.choice(DOMAINS)
    # email = f"kalawssimatrix+0{lname.lower()}@gmail.com"
    email = f"{fname}{num}{lname.lower()}@{domain}"
    username = f"{fname.lower()}{lname.lower()}{num}"
    password = f"{fname}{lname}{num}!"
    return {"first_name": fname, "last_name": lname, "email": email, "username": username, "password": password}
os.environ['CAMOUFOX_NO_UPDATE'] = '1'

VERSION = "v3.0.1"
BANNER = f"""
  ███╗   ██╗ ██████╗ ██╗   ██╗ █████╗     ██████╗ ██╗███╗   ██╗
  ████╗  ██║██╔═══██╗██║   ██║██╔══██╗    ██╔══██╗██║████╗  ██║
  ██╔██╗ ██║██║   ██║██║   ██║███████║    ██║  ██║██║██╔██╗ ██║
  ██║╚██╗██║██║   ██║╚██╗ ██╔╝██╔══██║    ██║  ██║██║██║╚██╗██║
  ██║ ╚████║╚██████╔╝ ╚████╔╝ ██║  ██║    ██████╔╝██║██║ ╚████║
  ╚═╝  ╚═══╝ ╚═════╝   ╚═══╝  ╚═╝  ╚═╝   ╚═════╝ ╚═╝╚═╝  ╚═══╝
                                                    {VERSION}
"""
print(BANNER)

def _device_id():
    """Stable device ID based on hostname + MAC."""
    mac = uuid.UUID(int=uuid.getnode()).hex[-12:]
    return f"{socket.gethostname()}-{mac}"

print(f"[device]  id       : {_device_id()}")
print(f"[device]  hostname : {socket.gethostname()}")
print(f"[device]  os       : {platform.system()} {platform.release()} ({platform.machine()})")
print(f"[device]  python   : {platform.python_version()}")
print(f"[device]  cpu      : {platform.processor() or 'n/a'}")
try:
    import psutil
    mem = psutil.virtual_memory()
    print(f"[device]  ram      : {mem.total // (1024**3)}GB total, {mem.percent}% used")
    print(f"[device]  cpu%     : {psutil.cpu_percent(interval=0.5)}%")
except ImportError:
    pass
print()

parser = argparse.ArgumentParser()
parser.add_argument('-c', metavar='COUNTRY', help='Use /ip/<country> endpoint and set exit IP (e.g. -c sw)')
args = parser.parse_args()

from camoufox.sync_api import Camoufox
from camoufox.addons import DefaultAddons
# import task_action
# import creep_session

import cv2, numpy as np

def find_and_click(page, templates, timeout=60, threshold=0.8):
    if isinstance(templates, str):
        templates = [templates]
    imgs = [(p, cv2.imread(p, cv2.IMREAD_COLOR)) for p in templates]
    deadline = time.time() + timeout
    while time.time() < deadline:
        screenshot = page.screenshot()
        screen = cv2.imdecode(np.frombuffer(screenshot, np.uint8), cv2.IMREAD_COLOR)
        for path, tmpl in imgs:
            res = cv2.matchTemplate(screen, tmpl, cv2.TM_CCOEFF_NORMED)
            _, max_val, _, max_loc = cv2.minMaxLoc(res)
            if max_val >= threshold:
                h, w = tmpl.shape[:2]
                cx, cy = max_loc[0] + w // 2, max_loc[1] + h // 2
                page.mouse.click(cx, cy)
                print(f"[cv2] matched {path} at ({cx},{cy}) conf={max_val:.2f}")
                return True
        time.sleep(0.5)
    print(f"[cv2] no match found for {templates}")
    return False

try:
    ip_info = requests.get("http://127.0.0.1:5000/ip", timeout=2).json()
    print(f"[proxy]   ip       : {ip_info}")
except (requests.exceptions.ConnectionError, requests.exceptions.ReadTimeout):
    ip_info = None
    print("[proxy]   no proxy found, skipping")



def checkpoint (step):
    print("Step :"+str(step))
from urllib.parse import urlencode

print(urlencode({"email": "test@example.com"}))
# email=test%40example.com


with Camoufox(headless=False, geoip=True) as fox:  # proxy={"server": "socks5://127.0.0.1:9050"}
    user = generate_user()
    email = user["email"]
    password = user["password"]
    first_name = user["first_name"]
    last_name = user["last_name"]
    full_name = f"{first_name} {last_name}"
    z_emzil = urlencode({"email": email})

    page = fox.new_page()
    # page.goto("https://www.google.com")
    DOOMED= "https://id.atlassian.com/signup/?email="+z_emzil
    page.goto(DOOMED)
    # page.goto("https://id.atlassian.com/signup/")
    # input('yyy')
    html = page.content()
    # with open("dump.html", "w") as f:
    #     f.write(html)
    # print("[dump] saved to dump.html")

    page.wait_for_selector('#email-uid1', state='visible', timeout=120000)
    page.locator('input[name="email"]')#.fill(email)
    print(f"[signup] email: {email}")
    page.locator('#signup-submit').click()
    print("[signup] clicked register")

    # Wait for signup button to be enabled again
    page.wait_for_function(
        "!document.querySelector('#signup-submit').disabled",
        timeout=30000
    )

    # Check for reCAPTCHA error in the specific container
    RECAPTCHA_ERR = "We are having trouble verifying reCAPTCHA for this request."
    RECAPTCHA_SEL = (
        "div.css-4b375e div._1e0c1txw._1bsb1osq._1tke1osq._2lx21bp4 "
        "div._16jlkb7n._1o9zkb7n._i0dl1wug._1e0c1txw "
        "div._16jlkb7n._1o9zkb7n._i0dl1wug._1ul9idpf._kqswh2mm._1pbykb7n "
        "div.css-1a99ai0 div#WhiteboxContainer.css-1r2hmps div.css-3pdudq "
        "section div div.css-haw22i "
        "section._2rko12b0._1rjcpxbi._18zrpxbi._1nmz1hna._bfhk1917"
    )
    try:
        err_el = page.query_selector(RECAPTCHA_SEL)
        has_recaptcha_err = err_el and RECAPTCHA_ERR in (err_el.inner_text() or "")
    except Exception:
        has_recaptcha_err = False

    if has_recaptcha_err:
        print("[signup] reCAPTCHA error detected — refreshing and retrying signup")
        page.reload()
        page.wait_for_selector('#signup-submit', state='visible', timeout=30000)
        page.wait_for_function(
            "!document.querySelector('#signup-submit').disabled",
            timeout=30000
        )
        page.locator('#signup-submit').click()
        print("[signup] clicked register again after refresh")

    # input('yyy')
    checkpoint(1)
    
    # page.locator('textarea[name="q"]').fill("bitbucket")
    # page.keyboard.press("Enter")
    print("[browser] searched for bitbucket")
    if not find_and_click(page, ["src/square.png", "src/square_2.png"]):
        print("[square] not found — jumping to 2FA step")
        goto_2fa = True
    else:
        goto_2fa = False
    time.sleep(1)
    page.screenshot(path="debug_head.png")
    print("[debug] saved debug_head.png")
    if goto_2fa:
        print("[square] not found — skipping all captcha steps, jumping to 2FA")
    else:
        try:
            # check if pass.png is visible — skip captcha steps and go straight to inin + 2FA
            if find_and_click(page, ["src/pass.png"], timeout=10):
                print("[pass] matched src/pass.png — skipping captcha steps")
                find_and_click(page, ["src/inin.png"])
            else:
                # click audio captcha button inside recaptcha iframe
                audio_clicked = False
                deadline = time.time() + 30
                while not audio_clicked and time.time() < deadline:
                    for iframe in page.frames:
                        try:
                            btn = iframe.query_selector('#recaptcha-audio-button')
                            if btn:
                                btn.click()
                                print("[captcha] clicked audio button")
                                audio_clicked = True
                                break
                        except Exception:
                            continue
                    if not audio_clicked:
                        time.sleep(0.5)

                if not audio_clicked:
                    find_and_click(page, ["src/head.png", "src/headphone.png", "src/headphone_2.png", "src/head2.png", "src/head1.png"])
                time.sleep(2)
                audio_src = None
                deadline = time.time() + 15
                while not audio_src and time.time() < deadline:
                    for iframe in page.frames:
                        try:
                            audio_src = iframe.eval_on_selector('#audio-source', 'el => el.src')
                            if audio_src:
                                print(f"[audio] src: {audio_src}")
                                if os.path.exists("key.mp3"):
                                    os.remove("key.mp3")
                                r = requests.get(audio_src)
                                with open("key.mp3", "wb") as f:
                                    f.write(r.content)
                                print(f"[audio] saved to key.mp3")
                                break
                        except Exception:
                            continue
                    if not audio_src:
                        time.sleep(0.5)

                # step: knok_knok
                import swis
                result = swis.swis()
                print(f"[knok_knok] {result}")

                find_and_click(page, ["src/key_text.png"])
                time.sleep(1)
                page.keyboard.type(result)
                page.keyboard.press("Enter")

                find_and_click(page, ["src/inin.png"])
                time.sleep(3)

            if find_and_click(page, ["src/chk_2.png"], timeout=16):
                page.keyboard.press("Enter")
                print("[chk] clicked chk_2.png and pressed Enter")
        except Exception as a:
            print(str(a))
            pass
    print("[4] Fetching 2FA code from email...")
    from get_2FA import get_2fa
    code = get_2fa("email="+email)
    if code:
        print(f"[4] 2FA code: {code}")
    else:
        print("[4] 2FA code not found.")

    try:
        print("[5] Entering OTP...")
        page.wait_for_selector('[data-testid="otp-input-index-0"]', timeout=30000)
        for i, char in enumerate(code or ""):
            page.click(f'[data-testid="otp-input-index-{i}"]')
            page.keyboard.type(char)
        print("[5] OTP entered.")
    except Exception as e:
        print(f"[5] ERROR entering OTP: {e}")
    
    try:
        print("[6] Waiting for display name field...")
        page.wait_for_selector('[data-testid="displayName"]', timeout=120000)
        full_name = f"{first_name} {last_name}"
        print(f"    Name: {full_name}")
        page.fill('[data-testid="displayName"]', full_name)
        page.keyboard.press("Tab")
        page.wait_for_timeout(300)
        page.keyboard.type(password)
        for _ in range(4):
            page.wait_for_timeout(400)
            page.keyboard.press("Tab")
        page.wait_for_timeout(400)
        page.keyboard.press("Enter")
        print("[6] Form submitted.")
    except Exception as e:
        print(f"[6] ERROR filling name/password: {e}")

    try:
        print("[7] Waiting for redirect to Atlassian home...")
        page.wait_for_url("https://home.atlassian.com/**", timeout=240000)
        print(f"[7] Success! URL: {page.url}")
        try:
            accept_btn = page.locator('xpath=/html/body/div[2]/div[2]/div[1]/div/div/div/div[2]/button[3]/span[2]')
            accept_btn.wait_for(state='visible', timeout=20000)
            accept_btn.click()
            print("[7] Clicked Accept all")
        except Exception:
            pass
        page.wait_for_selector('span:has-text("Home")', timeout=60000)
        print("[7] Home element appeared.")
        with open("accounts.txt", "a") as f:
            f.write(
                f"email   : {email}\n"
                f"name    : {full_name}\n"
                f"password: {password}\n\n"
            )
        print("[7] Account saved to accounts.txt")

        try:
            print("[8] Opening app.codeanywhere.com and clicking Bitbucket...")
            time.sleep(2)
            page.goto("https://app.codeanywhere.com/")
            ca_page = page
            print(f"[8] URL: {ca_page.url}")
            # Click GitLab first, then Tab to move to Bitbucket (below GitLab) and press Enter
            ca_page.wait_for_selector('#social-bitbucket', timeout=30000)
            ca_page.click('#social-bitbucket')
            print(f"[8] Clicked Bitbucket, URL: {ca_page.url}")
            ca_page.wait_for_selector('button[value="approve"]', timeout=120000)
            ca_page.click('button[value="approve"]')
            print(f"[8] Granted access, URL: {ca_page.url}")
        except Exception as e:
            print(f"[8] ERROR: {e}")
        # input('done!')

        try:
            print("[9] Waiting for New button...")
            ca_page.wait_for_selector('.Button_button__dboXH:has-text("New")', timeout=240000)
            ca_page.click('.Button_button__dboXH:has-text("New")')
            print("[9] Clicked New.")
            ca_page.wait_for_timeout(3000)

            print("[9] Dumping full page HTML for inspection...")
            with open("ca_page_dump.html", "w") as _f:
                _f.write(ca_page.content())
            print("[9] Saved to ca_page_dump.html")

            print("[9] Waiting for repository dropdown button...")
            ca_page.wait_for_selector('button.GitRepositoryDropdown_selected-option__4yDhC', timeout=60000)

            btn = ca_page.query_selector('button.GitRepositoryDropdown_selected-option__4yDhC')
            if 'expanded' not in (btn.get_attribute('class') or ''):
                btn.click()
                print("[9] Clicked dropdown to open.")
            else:
                print("[9] Dropdown already open.")

            print("[9] Waiting for 'empty' option...")
            ca_page.wait_for_selector('.GitRepositoryInfo_label__QUpyv', timeout=30000)
            target = ca_page.locator('.GitRepositoryInfo_label__QUpyv:text-is("Codeanywhere-Templates/empty")').first
            target.scroll_into_view_if_needed()
            target.click()
            print("[9] Repository selected.")

            all_cookies = page.context.cookies()
            ca_cookies = [c for c in all_cookies if 'codeanywhere.com' in c['domain']]
            os.makedirs("sessions", exist_ok=True)
            cookies_file = f"sessions/{email.split('@')[0]}.json"
            with open(cookies_file, "w") as f:
                json.dump({"email": email, "password": password, "cookies": all_cookies}, f, indent=2)
            print(f"[9] Saved {len(all_cookies)} cookies + credentials to {cookies_file}")

            print("[9] Waiting for Continue button...")
            ca_page.wait_for_selector('button[type="submit"]:has-text("Continue")', timeout=60000)
            ca_page.wait_for_function('document.querySelector(\'button[type="submit"]\') && !document.querySelector(\'button[type="submit"]\').disabled', timeout=60000)
            ca_page.click('button[type="submit"]:has-text("Continue")')
            print(f"[9] Clicked Continue, URL: {ca_page.url}")
            ca_page.wait_for_timeout(20000)
            print("[9] Checking if workspace is setting up...")
            while ca_page.query_selector('.WorkspaceLogs_top-level-message__zu6NS'):
                print("[9] Still setting up workspace, waiting...")
                ca_page.wait_for_timeout(5000)
            print("[9] Workspace ready.")
            # input('lol')
            input('')
        except Exception as e:
            print(f"[9] ERROR: {e}")
    except Exception as e:
        print(f"[7] ERROR waiting for redirect: {e}")

    input("[browser] press Enter to close...")
