import sys, time, os

KEY_FILE = os.path.join(os.path.dirname(__file__), "key.mp3")

def get_key() -> str:
    frames = ["🔑", "✨", "🔗", "💫", "🛡️"]
    for i in range(15):
        bar = "█" * (i + 1) + "░" * (14 - i)
        sys.stdout.write(f"\r{frames[i % len(frames)]}  [{bar}]  LOADING KEY AUDIO")
        sys.stdout.flush()
        time.sleep(0.05)

    print(f"\n\n  🎵  File  ➜  \033[1;36m{KEY_FILE}\033[0m\n")
    return KEY_FILE
