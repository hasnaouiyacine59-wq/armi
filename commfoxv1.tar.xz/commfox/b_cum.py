import os, json, time, random, requests, argparse, platform, uuid, socket, sys, threading
from faker import Faker
fake = Faker()
#efahsruujuerkazj
#

# ── colours ────────────────────────────────────────────────────────────────────
R  = "\033[31m"   # red
G  = "\033[32m"   # green
Y  = "\033[33m"   # yellow
B  = "\033[34m"   # blue
M  = "\033[35m"   # magenta
C  = "\033[36m"   # cyan
W  = "\033[37m"   # white
DIM= "\033[2m"
RST= "\033[0m"

def log(tag, msg, color=W):
    ts = time.strftime("%H:%M:%S")
    print(f"{DIM}[{ts}]{RST} {color}[{tag}]{RST} {msg}")

def ok(tag, msg):   log(tag, msg, G)
def err(tag, msg):  log(tag, msg, R)
def info(tag, msg): log(tag, msg, C)
def warn(tag, msg): log(tag, msg, Y)

class Spinner:
    _frames = ["⠋","⠙","⠹","⠸","⠼","⠴","⠦","⠧","⠇","⠏"]
    def __init__(self, label):
        self.label = label
        self._stop = threading.Event()
        self._t = threading.Thread(target=self._spin, daemon=True)
    def _spin(self):
        i = 0
        while not self._stop.is_set():
            sys.stdout.write(f"\r{M}{self._frames[i % len(self._frames)]}{RST} {self.label}  ")
            sys.stdout.flush()
            time.sleep(0.08)
            i += 1
    def __enter__(self):
        self._t.start(); return self
    def __exit__(self, *_):
        self._stop.set(); self._t.join()
        sys.stdout.write("\r\033[K")  # clear spinner line
        sys.stdout.flush()

def random_num():
    return random.randint(100, 999)

def generate_user():
    fname = fake.first_name()
    lname = fake.last_name()
    num = random_num()
    DOMAINS = [
    "alpha804.eu.org",
    "alpha-sig.eu.org",
    "beta-sig.eu.org",
    "bitcoin-plazza.eu.org",
    "c0rner-bit.eu.org",
    "dark0s-market.eu.org",
    "gamma-sig.eu.org",
    "iblogg.eu.org",
    "lg-salmi.nl.eu.org",
    "m0rd05.eu.org",
    "sec4891.eu.org",
    "techstreet07.eu.org",
    "vaya.eu.org",
    "w0rld.int.eu.org",
    "ziw05tempemail.eu.org",
    "ziw0tempemail.eu.org",
]

    # DOMAINS = ["techxbox.eu.org", "beta-sig.eu.org", "itchigho.eu.org", "sec4891.eu.org", "youoneshell.eu.org"]
    domain = random.choice(DOMAINS)
    # email = f"kalawssimatrix+0{lname.lower()}@gmail.com"
    # email = f"andrmidal84a+0{lname.lower()}@gmail.com"
    email = f"{fname}{num}{lname.lower()}@{domain}"
    username = f"{fname.lower()}{lname.lower()}{num}"
    password = f"{fname}{lname}{num}!"
    return {"first_name": fname, "last_name": lname, "email": email, "username": username, "password": password}
os.environ['CAMOUFOX_NO_UPDATE'] = '1'

VERSION = "v3.0.1"
BANNER = f"""
                    /|                 |\\ 
                   / |                 | \\
                  /  |    /\\     /\\    |  \\
                 /   |   /  \\   /  \\   |   \\
                / ___| _/ /\\ \\_/ /\\ \\_ |___ \\
               /  ___/  \\/  \\ /  \\/  \\  \\___ \\
              ( (  /  /\\  \\  V  /  /\\  \\  \\ ) )
               \\ \\_\\ /  \\ /\\ | /\\ / \\ \\_/ /_/
                \\___/    V  \\|/  V    \\___/
                    \\    |\\___/|    /
                     \\   |     |   /
                      \\  | o o |  /
                       \\_|  ^  |_/
                         | \\_/ |
                         |     |       {VERSION}
                        /|     |\\
                       / |     | \\
"""
print(BANNER)

def _device_id():
    """Stable device ID based on hostname + MAC."""
    mac = uuid.UUID(int=uuid.getnode()).hex[-12:]
    return f"{socket.gethostname()}-{mac}"

print(f"{B}┌─ device ──────────────────────────────────────{RST}")
print(f"{B}│{RST}  id       : {_device_id()}")
print(f"{B}│{RST}  hostname : {socket.gethostname()}")
print(f"{B}│{RST}  os       : {platform.system()} {platform.release()} ({platform.machine()})")
print(f"{B}│{RST}  python   : {platform.python_version()}")
print(f"{B}│{RST}  cpu      : {platform.processor() or 'n/a'}")
try:
    import psutil
    mem = psutil.virtual_memory()
    print(f"{B}│{RST}  ram      : {mem.total // (1024**3)}GB total, {mem.percent}% used")
    print(f"{B}│{RST}  cpu%     : {psutil.cpu_percent(interval=0.5)}%")
except ImportError:
    pass
print(f"{B}└───────────────────────────────────────────────{RST}\n")

parser = argparse.ArgumentParser()
parser.add_argument('-c', metavar='COUNTRY', help='Use /ip/<country> endpoint and set exit IP (e.g. -c sw)')
args = parser.parse_args()

from camoufox.sync_api import Camoufox
from camoufox.addons import DefaultAddons
# import task_action
# import creep_session

import cv2, numpy as np

def find_and_click(page, templates, timeout=60, threshold=0.8):
    if isinstance(templates, str):
        templates = [templates]
    imgs = [(p, cv2.imread(p, cv2.IMREAD_COLOR)) for p in templates]
    deadline = time.time() + timeout
    while time.time() < deadline:
        screenshot = page.screenshot()
        screen = cv2.imdecode(np.frombuffer(screenshot, np.uint8), cv2.IMREAD_COLOR)
        for path, tmpl in imgs:
            res = cv2.matchTemplate(screen, tmpl, cv2.TM_CCOEFF_NORMED)
            _, max_val, _, max_loc = cv2.minMaxLoc(res)
            if max_val >= threshold:
                h, w = tmpl.shape[:2]
                cx, cy = max_loc[0] + w // 2, max_loc[1] + h // 2
                page.mouse.click(cx, cy)
                ok("cv2", f"matched {path} at ({cx},{cy}) conf={max_val:.2f}")
                return True
        time.sleep(0.5)
    err("cv2", f"no match found for {templates}")
    return False

try:
    with Spinner("connecting to proxy..."):
        ip_info = requests.get("http://127.0.0.1:5000/ip", timeout=2).json()
    ok("proxy", f"ip : {ip_info}")
except (requests.exceptions.ConnectionError, requests.exceptions.ReadTimeout):
    ip_info = None
    warn("proxy", "no proxy found, skipping")


def checkpoint(step):
    print(f"\n{Y}{'─'*50}{RST}")
    info("step", f"{step}")
    print(f"{Y}{'─'*50}{RST}\n")

from urllib.parse import urlencode

print(urlencode({"email": "test@example.com"}))
# email=test%40example.com


with Camoufox(headless=False, geoip=True) as fox:  # proxy={"server": "socks5://127.0.0.1:9050"}
    user = generate_user()
    email = user["email"]
    password = user["password"]
    first_name = user["first_name"]
    last_name = user["last_name"]
    full_name = f"{first_name} {last_name}"
    z_emzil = urlencode({"email": email})

    page = fox.new_page()
    # page.goto("https://www.google.com")
    # DOOMED= "https://id.atlassian.com/signup/?email="+z_emzil
    DOOMED= "https://id.atlassian.com/signup/?"+z_emzil
    page.goto(DOOMED)
    # Wait for at least one button to appear before scanning
    try:
        page.wait_for_selector('button', timeout=15000)
    except Exception:
        warn("slack", "timed out waiting for buttons")
    buttons = page.query_selector_all('button')
    info("buttons", f"found {len(buttons)} buttons:")
    slack_btn = None
    for btn in buttons:
        txt = (btn.inner_text() or "").strip()
        print(f"  {DIM}-{RST} {txt!r}")
        if "slack" in txt.lower():
            slack_btn = btn
    if slack_btn:
        ok("slack", "found Slack button!")
        slack_btn.click()
    else:
        warn("slack", "no Slack button found")
    page.goto(DOOMED)

    page.wait_for_selector('#email-uid1', state='visible', timeout=120000)
    page.locator('input[name="email"]')#.fill(email)
    info("signup", f"email: {email}")
    page.locator('#signup-submit').click()
    info("signup", "clicked register")

    # Wait for signup button to be enabled again
    page.wait_for_function(
        "!document.querySelector('#signup-submit').disabled",
        timeout=30000
    )

    # Check for reCAPTCHA error in the specific container
    RECAPTCHA_ERR = "We are having trouble verifying reCAPTCHA for this request."
    RECAPTCHA_SEL = (
        "div.css-4b375e div._1e0c1txw._1bsb1osq._1tke1osq._2lx21bp4 "
        "div._16jlkb7n._1o9zkb7n._i0dl1wug._1e0c1txw "
        "div._16jlkb7n._1o9zkb7n._i0dl1wug._1ul9idpf._kqswh2mm._1pbykb7n "
        "div.css-1a99ai0 div#WhiteboxContainer.css-1r2hmps div.css-3pdudq "
        "section div div.css-haw22i "
        "section._2rko12b0._1rjcpxbi._18zrpxbi._1nmz1hna._bfhk1917"
    )
    try:
        err_el = page.query_selector(RECAPTCHA_SEL)
        has_recaptcha_err = err_el and RECAPTCHA_ERR in (err_el.inner_text() or "")
    except Exception:
        has_recaptcha_err = False

    if has_recaptcha_err:
        warn("signup", "reCAPTCHA error detected — refreshing and retrying")
        page.reload()
        page.wait_for_selector('#signup-submit', state='visible', timeout=30000)
        page.wait_for_function(
            "!document.querySelector('#signup-submit').disabled",
            timeout=30000
        )
        page.locator('#signup-submit').click()
        info("signup", "clicked register again after refresh")

    # input('yyy')
    checkpoint(1)
    
    if not find_and_click(page, ["src/square.png", "src/square_2.png"]):
        warn("square", "not found — jumping to 2FA step")
        goto_2fa = True
    else:
        goto_2fa = False
    time.sleep(1)
    page.screenshot(path="debug_head.png")
    info("debug", "saved debug_head.png")
    if goto_2fa:
        warn("square", "skipping all captcha steps, jumping to 2FA")
    else:
        try:
            if find_and_click(page, ["src/pass.png"], timeout=10):
                info("pass", "matched src/pass.png — skipping captcha steps")
                find_and_click(page, ["src/inin.png"])
            else:
                audio_clicked = False
                deadline = time.time() + 30
                while not audio_clicked and time.time() < deadline:
                    for iframe in page.frames:
                        try:
                            btn = iframe.query_selector('#recaptcha-audio-button')
                            if btn:
                                btn.click()
                                ok("captcha", "clicked audio button")
                                audio_clicked = True
                                break
                        except Exception:
                            continue
                    if not audio_clicked:
                        time.sleep(0.5)

                if not audio_clicked:
                    find_and_click(page, ["src/head.png", "src/headphone.png", "src/headphone_2.png", "src/head2.png", "src/head1.png"])
                time.sleep(2)
                audio_src = None
                deadline = time.time() + 15
                while not audio_src and time.time() < deadline:
                    for iframe in page.frames:
                        try:
                            audio_src = iframe.eval_on_selector('#audio-source', 'el => el.src')
                            if audio_src:
                                info("audio", f"src: {audio_src}")
                                if os.path.exists("key.mp3"):
                                    os.remove("key.mp3")
                                with Spinner("downloading audio challenge..."):
                                    r = requests.get(audio_src)
                                with open("key.mp3", "wb") as f:
                                    f.write(r.content)
                                ok("audio", "saved to key.mp3")
                                break
                        except Exception:
                            continue
                    if not audio_src:
                        time.sleep(0.5)

                import swis
                result = swis.swis()
                ok("knok_knok", f"{result}")

                find_and_click(page, ["src/key_text.png"])
                time.sleep(1)
                page.keyboard.type(result)
                page.keyboard.press("Enter")

                find_and_click(page, ["src/inin.png"])
                time.sleep(3)

            if find_and_click(page, ["src/chk_2.png"], timeout=16):
                page.keyboard.press("Enter")
                ok("chk", "clicked chk_2.png and pressed Enter")
        except Exception as a:
            err("captcha", str(a))
    with Spinner("fetching 2FA code from email..."):
        from get_2FA import get_2fa
        code = get_2fa(email)
    if code:
        ok("2fa", f"code: {code}")
    else:
        err("2fa", "code not found")

    try:
        info("otp", "entering OTP...")
        page.wait_for_selector('[data-testid="otp-input-index-0"]', timeout=30000)
        for i, char in enumerate(code or ""):
            page.click(f'[data-testid="otp-input-index-{i}"]')
            page.keyboard.type(char)
        ok("otp", "OTP entered")
    except Exception as e:
        err("otp", str(e))

    try:
        with Spinner("waiting for display name field..."):
            page.wait_for_selector('[data-testid="displayName"]', timeout=120000)
        full_name = f"{first_name} {last_name}"
        info("profile", f"name: {full_name}")
        page.fill('[data-testid="displayName"]', full_name)
        page.keyboard.press("Tab")
        page.wait_for_timeout(300)
        page.keyboard.type(password)
        for _ in range(4):
            page.wait_for_timeout(400)
            page.keyboard.press("Tab")
        page.wait_for_timeout(400)
        page.keyboard.press("Enter")
        ok("profile", "form submitted")
    except Exception as e:
        err("profile", str(e))

    try:
        with Spinner("waiting for Atlassian home redirect..."):
            page.wait_for_url("https://home.atlassian.com/**", timeout=240000)
        ok("redirect", f"success → {page.url}")
        try:
            accept_btn = page.locator('xpath=/html/body/div[2]/div[2]/div[1]/div/div/div/div[2]/button[3]/span[2]')
            accept_btn.wait_for(state='visible', timeout=20000)
            accept_btn.click()
            ok("cookies", "clicked Accept all")
        except Exception:
            pass
        with Spinner("waiting for Home element..."):
            page.wait_for_selector('span:has-text("Home")', timeout=60000)
        ok("home", "Home element appeared")
        with open("accounts.txt", "a") as f:
            f.write(f"email   : {email}\nname    : {full_name}\npassword: {password}\n\n")
        ok("save", f"account saved to accounts.txt")

        ca_page = page
        try:
            info("ca", "opening app.codeanywhere.com...")
            time.sleep(2)
            page.goto("https://app.codeanywhere.com/")
            info("ca", f"url: {ca_page.url}")
            with Spinner("waiting for Bitbucket button..."):
                ca_page.wait_for_selector('#social-bitbucket', timeout=30000)
            ca_page.click('#social-bitbucket')
            info("ca", f"clicked Bitbucket → {ca_page.url}")
            with Spinner("waiting for approve button..."):
                ca_page.wait_for_selector('button[value="approve"]', timeout=120000)
            ca_page.click('button[value="approve"]')
            ok("ca", f"granted access → {ca_page.url}")
        except Exception as e:
            err("ca", str(e))

        try:
            with Spinner("waiting for New button..."):
                ca_page.wait_for_selector('.Button_button__dboXH:has-text("New")', timeout=240000)
            ca_page.click('.Button_button__dboXH:has-text("New")')
            ok("ca", "clicked New")

            all_cookies = page.context.cookies()
            os.makedirs("sessions", exist_ok=True)
            cookies_file = f"sessions/{email.split('@')[0]}.json"
            with open(cookies_file, "w") as f:
                json.dump({"email": email, "password": password, "cookies": all_cookies}, f, indent=2)
            ok("ca", f"saved {len(all_cookies)} cookies to {cookies_file}")

            # ca_page.wait_for_timeout(3000)

            # with open("ca_page_dump.html", "w") as _f:
            #     _f.write(ca_page.content())
            # info("ca", "saved ca_page_dump.html")

            # with Spinner("waiting for repo dropdown..."):
            #     ca_page.wait_for_selector('button.GitRepositoryDropdown_selected-option__4yDhC', timeout=60000)
            # btn = ca_page.query_selector('button.GitRepositoryDropdown_selected-option__4yDhC')
            # if 'expanded' not in (btn.get_attribute('class') or ''):
            #     btn.click()
            #     info("ca", "clicked dropdown to open")
            # else:
            #     info("ca", "dropdown already open")

            # with Spinner("waiting for empty template option..."):
            #     ca_page.wait_for_selector('.GitRepositoryInfo_label__QUpyv', timeout=30000)
            # target = ca_page.locator('.GitRepositoryInfo_label__QUpyv:text-is("Codeanywhere-Templates/empty")').first
            # target.scroll_into_view_if_needed()
            # target.click()
            # ok("ca", "repository selected")

            # with Spinner("waiting for Continue button..."):
            #     ca_page.wait_for_selector('button[type="submit"]:has-text("Continue")', timeout=60000)
            #     ca_page.wait_for_function('document.querySelector(\'button[type="submit"]\') && !document.querySelector(\'button[type="submit"]\').disabled', timeout=60000)
            # ca_page.click('button[type="submit"]:has-text("Continue")')
            # info("ca", f"clicked Continue → {ca_page.url}")
            # ca_page.wait_for_timeout(20000)
            # while ca_page.query_selector('.WorkspaceLogs_top-level-message__zu6NS'):
            #     info("ca", "setting up workspace...")
            #     ca_page.wait_for_timeout(5000)
            # ok("ca", "workspace ready")
            # input('')
        except Exception as e:
            err("ca", str(e))
    except Exception as e:
        err("redirect", str(e))

    input(f"\n{DIM}press Enter to close...{RST}")
