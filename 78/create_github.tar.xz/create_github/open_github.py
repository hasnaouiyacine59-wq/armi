import random
import string
import argparse
import time
import json
import os
import base64
from playwright.sync_api import sync_playwright
from read_mail import get_code


parser = argparse.ArgumentParser()
parser.add_argument("-p", "--proxy", type=str, default=None, help="Proxy URL e.g. http://user:pass@host:port")
args = parser.parse_args()

# DOMAINS = [
#     "bitcoin-plazza.eu.org",
#     "itchigho.eu.org",
#     "techxbox.eu.org",
#     "youoneshell.eu.org",
# ]
DOMAINS = [
    "alpha804.eu.org",
    "alpha-sig.eu.org",
    "beta-sig.eu.org",
    "bitcoin-plazza.eu.org",
    "c0rner-bit.eu.org",
    "dark0s-market.eu.org",
    "gamma-sig.eu.org",
    "iblogg.eu.org",
    "lg-salmi.nl.eu.org",
    "m0rd05.eu.org",
    "sec4891.eu.org",
    "techstreet07.eu.org",
    "vaya.eu.org",
    "w0rld.int.eu.org",
    "ziw05tempemail.eu.org",
    "ziw0tempemail.eu.org",
]
def random_email():
    name = ''.join(random.choices(string.ascii_lowercase, k=8))
    return f"{name}@{random.choice(DOMAINS)}"

def h():
    time.sleep(random.uniform(0.3, 1.2))

email = random_email()
_prefixes = ["sim0", "nx0", "vx3", "kr4t", "z3ph", "d4rk", "bl4ze", "cy4n", "n3on", "px7", "rx9", "t3ch", "wr4th", "sk1d", "gl1ch"]
username = f"{random.choice(_prefixes)}-dev-{random.randint(10000, 99999)}"
password = base64.b64encode(email.encode()).decode()

print(f"Email: {email}")
print(f"Username: {username}")
print(f"password: {password}")

url = f"https://github.com/signup?source=form-home-signup&user_email={email}"

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
]

VIEWPORTS = [
    {"width": 1366, "height": 768},
    {"width": 1920, "height": 1080},
    {"width": 1440, "height": 900},
    {"width": 1536, "height": 864},
]

with sync_playwright() as p:
    browser = p.chromium.launch(
        executable_path="/usr/bin/google-chrome",
        headless=False,
        args=[
            "--disable-blink-features=AutomationControlled",
            "--no-sandbox",
            "--disable-infobars",
            "--incognito",
        ]
    )
    viewport = random.choice(VIEWPORTS)
    proxy_config = None
    if args.proxy:
        from urllib.parse import urlparse
        p_url = urlparse(args.proxy)
        proxy_config = {
            "server": f"{p_url.scheme}://{p_url.hostname}:{p_url.port}",
            "username": p_url.username,
            "password": p_url.password,
        }
    context = browser.new_context(
        user_agent=random.choice(USER_AGENTS),
        viewport=viewport,
        locale="en-US",
        timezone_id="America/New_York",
        permissions=["geolocation"],
        color_scheme="light",
        proxy=proxy_config,
    )
    context.add_init_script("""
        Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
        Object.defineProperty(navigator, 'plugins', { get: () => [1, 2, 3, 4, 5] });
        Object.defineProperty(navigator, 'languages', { get: () => ['en-US', 'en'] });
        window.chrome = { runtime: {} };

        // Canvas fingerprint noise
        const origToDataURL = HTMLCanvasElement.prototype.toDataURL;
        HTMLCanvasElement.prototype.toDataURL = function(type) {
            const ctx = this.getContext('2d');
            if (ctx) {
                const shift = Math.floor(Math.random() * 10) - 5;
                ctx.fillStyle = `rgba(0,0,0,0.0${Math.abs(shift)})`;
                ctx.fillRect(0, 0, 1, 1);
            }
            return origToDataURL.apply(this, arguments);
        };

        // WebGL fingerprint noise
        const origGetParameter = WebGLRenderingContext.prototype.getParameter;
        WebGLRenderingContext.prototype.getParameter = function(param) {
            if (param === 37445) return 'Intel Inc.';
            if (param === 37446) return 'Intel Iris OpenGL Engine';
            return origGetParameter.apply(this, arguments);
        };
    """)
    page = context.new_page()
    page.goto(url, timeout=90000, wait_until="domcontentloaded")

    page.wait_for_selector("#login", timeout=60000)
    h()
    page.fill("#login", username)
    h()
    page.fill("#password", password)
    h()
    page.keyboard.press("Tab"); h()
    page.keyboard.press("Tab"); h()
    page.keyboard.press("Tab"); h()
    page.keyboard.press("Tab"); h()
    page.keyboard.press("Enter")

    input("Solve the puzzle then press Enter to fetch code...")

    print("Fetching activation code from email...")
    code = get_code(email)
    if code:
        print(f"Got code: {code}")
        h()
        # Fill each OTP digit into its own field
        for i, digit in enumerate(code):
            selector = f"#launch-code-{i}"
            try:
                page.click(selector)
                h()
                page.fill(selector, digit)
                h()
            except Exception as e:
                print(f"Could not fill {selector}: {e}")

        # After code entry GitHub may go to dashboard or profile setup, not login
        try:
            page.wait_for_selector("#login_field", timeout=8000)
            h()
            page.fill("#login_field", username)
            h()
            page.keyboard.press("Tab")
            h()

            page.fill("input[name='password']", password)
            h()
            page.keyboard.press("Tab")
            h()
            page.keyboard.press("Tab")
            h()
            page.keyboard.press("Enter")
        except Exception:
            pass  # Already authenticated via signup flow
        input("Press Enter when ready to save cookies (complete any remaining steps first)...")
        cookies = context.cookies()
        github_cookies = [c for c in cookies if "github.com" in c["domain"]]
        account = {"username": username, "email": email, "password": password, "cookies": github_cookies}
        with open(f"{username}.json", "w") as f:
            json.dump(account, f, indent=2)
        print(f"Saved: {username}.json ({len(github_cookies)} cookies)")
    else:
        print("Could not retrieve activation code.")

    input("Press Enter to close...")
    browser.close()
