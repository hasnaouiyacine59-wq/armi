import imaplib
import email
import re
import time

IMAP_HOST = '127.0.0.1'
IMAP_PORT = 1143
USERNAME = 'za_bang_0_0_bang@proton.me'
PASSWORD = 'agoon007A*'

def get_github_code(retries=10, delay=5):
    for _ in range(retries):
        mail = imaplib.IMAP4(IMAP_HOST, IMAP_PORT)
        mail.login(USERNAME, PASSWORD)
        mail.select("INBOX")

        status, messages = mail.search(None, "ALL")
        email_ids = messages[0].split()

        for e_id in reversed(email_ids):
            status, msg_data = mail.fetch(e_id, "(RFC822)")
            for response_part in msg_data:
                if isinstance(response_part, tuple):
                    msg = email.message_from_bytes(response_part[1])
                    subject = msg.get("subject", "")
                    if "GitHub" not in subject:
                        continue

                    body = ""
                    if msg.is_multipart():
                        for part in msg.walk():
                            if part.get_content_type() == "text/plain":
                                body = part.get_payload(decode=True).decode(errors="ignore")
                                break
                    else:
                        body = msg.get_payload(decode=True).decode(errors="ignore")

                    match = re.search(r'entering the code below:\s*(\d+)', body)
                    if match:
                        mail.logout()
                        return match.group(1)

        mail.logout()
        print(f"Code not found, retrying in {delay}s...")
        time.sleep(delay)

    return None

if __name__ == "__main__":
    code = get_github_code()
    print(f"Activation code: {code}" if code else "Code not found")
